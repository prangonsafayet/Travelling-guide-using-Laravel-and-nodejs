<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Oops!</h2>
	<p>Username already exists. Please select a different username</p>
	<p>Click <a href="/register">here</a> to go back</p>
</body>
</html>