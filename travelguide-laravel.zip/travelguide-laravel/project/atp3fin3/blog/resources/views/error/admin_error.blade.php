<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h2>Oops!</h2>
	<p>Not an admin or user!!</p>
	<p>Click <a href="/home">here</a> to go back</p>
</body>
</html>