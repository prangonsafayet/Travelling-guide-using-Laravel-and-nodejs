// DECLARATION
var express = require('express');
var router = express.Router();
var asyncValidator = require('async-validator');
var userRules = require.main.require('./validation-rules/user');

var userModel = require.main.require('./models/admin-delete-model');

router.get('/', function(req, res){
	userModel.getAll(function(result){
		res.render('delete/index', {userList: result});
		//res.json(result);
	});
});
router.post('/', function(req, res){
	var user = {
        user_id: req.body.user_id,
	};
	
	userModel.delete(user, function(result){
				res.redirect('/ad_delete');
			});

});

module.exports = router;