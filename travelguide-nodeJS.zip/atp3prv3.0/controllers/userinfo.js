// DECLARATION
var express = require('express');
var router = express.Router();
var asyncValidator = require('async-validator');
var userRules = require.main.require('./validation-rules/user');

var userModel = require.main.require('./models/admin-userinfo-model');


//router.get('/', function(req, res){
//    if(req.session.loggedUser == user){
//        alert("I am an alert box!");
//        res.render('error/admin_error');
//    }
//    if(req.session.loggedUser == admin){
//        userModel.getAll(function(result){
//		res.render('admin-userinfo/index', {userList: result});
//		//res.json(result);
//	});
//    }
//	
//});
router.get('*', function(req, res, next){
	if(req.session.loggedUser == user){
        //alert("I am an alert box!");
        res.render('error/admin_error');
    }
	
    

	if(req.session.loggedUser == admin){
        userModel.getAll(function(result){
		res.render('admin-userinfo/index', {userList: result});
		//res.json(result);
	});
    }
	next();
});

module.exports = router;