// DECLARATION
var express = require('express');
var router = express.Router();

router.get('/', function(req, res){
	
	res.render('foy/foy')
});


module.exports = router;