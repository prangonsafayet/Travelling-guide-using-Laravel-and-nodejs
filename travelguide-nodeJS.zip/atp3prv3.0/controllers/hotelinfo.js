// DECLARATION
var express = require('express');
var router = express.Router();
var asyncValidator = require('async-validator');
var userRules = require.main.require('./validation-rules/user');

var userModel = require.main.require('./models/admin-hotelinfo-model');


router.get('/', function(req, res){
	userModel.getAll(function(result){
		res.render('hotelinfo/index', {userList: result});
		//res.json(result);
	});
});
router.post('/', function(req, res){
	var user = {
        h_id: req.body.h_id,
        no_rooms: req.body.no_rooms

	};
	
	userModel.addi(user, function(result){
        res.redirect('/hotelinfo');
    });
});

module.exports = router;