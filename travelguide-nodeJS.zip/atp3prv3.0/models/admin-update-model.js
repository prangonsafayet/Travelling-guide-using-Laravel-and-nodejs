var db = require('./db');
module.exports = {
	getAll:function(callback){
		var sql = "SELECT * FROM userinfo";
		db.getData(sql, null, function (results) {
			callback(results);
		});
	},
	update: function(user, callback){
		var sql = "UPDATE userinfo SET Password=? where user_id=? ";
		var param = [user.password,user.user_id];
		db.getData(sql, param, function (results) {
			callback(results);
		});
	}


};