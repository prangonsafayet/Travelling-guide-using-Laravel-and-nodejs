var db = require('./db');
module.exports = {
	getAll:function(callback){
		var sql = "SELECT * FROM hotels;";
		db.getData(sql, null, function (results) {
			callback(results);
		});
	},
    addi: function(user, callback){
		var sql = "UPDATE hotels SET Booked_room=Booked_room+? WHERE h_id=?";
		var param = [user.no_rooms,user.h_id];
		db.getData(sql, param, function (results) {
            console.log(user.no_rooms);
            console.log("lalalalalala");
			callback(results);
		});
	}
};
