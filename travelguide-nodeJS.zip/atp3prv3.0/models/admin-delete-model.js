var db = require('./db');
module.exports = {
	getAll:function(callback){
		var sql = "SELECT * FROM userinfo";
		db.getData(sql, null, function (results) {
			callback(results);
		});
	},
	delete: function(user, callback){
		var sql = "DELETE FROM userinfo WHERE user_id= ?";
		var param = [user.user_id];
		db.getData(sql, param, function (results) {
			callback(results);
		});
	}


};