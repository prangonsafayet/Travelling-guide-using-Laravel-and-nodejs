var db = require('./db');
module.exports = {
	getAll:function(callback){
		var sql = "SELECT * FROM queries";
		db.getData(sql, null, function (results) {
			callback(results);
		});
	}
};