// DECLARATION
var express = require('express');
var app = express();
var port = 1337;

var path = require('path');
var bodyParser = require('body-parser');
var expressSession = require('express-session');

var login = require('./controllers/login');
var logout = require('./controllers/logout');
var home = require('./controllers/home');
var gallery= require('./controllers/gallery');
var cox= require('./controllers/cox');
var foy= require('./controllers/foy');
var jaf= require('./controllers/jaf');
var law= require('./controllers/law');
var rang= require('./controllers/rang');
var saj= require('./controllers/saj');
var st= require('./controllers/st');
var sun= require('./controllers/sun');
var register= require('./controllers/register');
var adminHome=  require('./controllers/adminhome');
var userinfo= require('./controllers/userinfo');
var queries= require('./controllers/queries');
var contact_us = require('./controllers/contact_us');
var ad_delete = require('./controllers/ad_delete');
var ad_update = require('./controllers/ad_update');
var hotel = require('./controllers/hotel');
var places = require('./controllers/places');
var hotelinfo = require('./controllers/hotelinfo');



// CONOFIGURE
app.set('view engine', 'ejs');
//app.set('views', path.join(__dirname, 'html/views'));

// MIDDLEWARE
app.use(bodyParser.urlencoded({extended: false}));
app.use(expressSession({secret: 'sryigoahlnsdbflsidyf', saveUninitialized: true, resave: false}));

app.use(express.static(path.join(__dirname, 'node_modules/bootstrap3/dist')));
app.use(express.static('./node_modules/jquery/dist'));
app.use(express.static('./public'));


// ROUTES

app.get('*', function(req, res, next){
	if(req.url == '/' || req.url == '/login' || req.url=='/register')
	{
		next();
		return;
	}
	
    

	if(req.session.loggedUser == null)
	{
		res.redirect('/login');
		return;
	}
	next();
});

app.get('/', function(req, res){
	res.redirect('/login');
});

app.use('/login', login);
app.use('/register',register);
app.use('/logout', logout);
app.use('/home', home);
app.use('/gallery', gallery);
app.use('/cox',cox);
app.use('/foy',foy);
app.use('/jaf',jaf);
app.use('/law',law);
app.use('/rang',rang);
app.use('/saj',saj);
app.use('/st',st);
app.use('/sun',sun);
app.use('/adminhome',adminHome);
app.use('/userinfo',userinfo);
app.use('/queries',queries);
app.use('/contact_us',contact_us);
app.use('/ad_delete',ad_delete);
app.use('/ad_update',ad_update);
app.use('/hotel',hotel);
app.use('/places',places);
app.use('/hotelinfo',hotelinfo);


// SERVER START
app.listen(port, function(){
	console.log('Listenting at port ' + port + ' ...');
});